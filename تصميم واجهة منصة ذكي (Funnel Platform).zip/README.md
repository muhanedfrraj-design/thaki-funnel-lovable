
  # تصميم واجهة منصة ذكي (Funnel Platform)

  This is a code bundle for تصميم واجهة منصة ذكي (Funnel Platform). The original project is available at https://www.figma.com/design/FOy1kpfq8sGNrdDw8eO6EN/%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D9%88%D8%A7%D8%AC%D9%87%D8%A9-%D9%85%D9%86%D8%B5%D8%A9-%D8%B0%D9%83%D9%8A--Funnel-Platform-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  